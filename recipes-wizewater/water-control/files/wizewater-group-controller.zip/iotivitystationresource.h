#ifndef IOTIVITYSTATIONRESOURCE_H
#define IOTIVITYSTATIONRESOURCE_H

#include <QObject>
#include <ocstack.h>
#include <OCPlatform.h>
#include <OCApi.h>

#include "defines.h"

using namespace std;
using namespace OC;
namespace PH = std::placeholders;

class IoTivityStationResource : public QObject
{
    Q_OBJECT

public:
    OCResourceHandle m_resourceHandle;
    OCRepresentation m_rep;
    std::string resourceURI;
    std::string resourceTypeName;

    int m_n;
    bool m_isOn;

    explicit IoTivityStationResource(std::string deviceUuid, int n, QObject *parent = nullptr);
    explicit IoTivityStationResource(QObject *parent = nullptr);

    void create();

    void setIsOn(bool on);
    OCRepresentation get();
    void put(const OCRepresentation& rep);

    OCEntityHandlerResult entityHandler(std::shared_ptr<OCResourceRequest> request);

signals:
    void updated(IoTivityStationResource* station);

public slots:
};

#endif // IOTIVITYSTATIONRESOURCE_H
