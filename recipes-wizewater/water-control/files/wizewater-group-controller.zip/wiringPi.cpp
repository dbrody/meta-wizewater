#include "wiringPi.h"

int wiringPiSetup (void)
{
    return 0;
}

void pinMode (int pin, int mode)
{
}

void digitalWrite (int pin, int value)
{
}

int digitalRead (int pin)
{
    return 0;
}
