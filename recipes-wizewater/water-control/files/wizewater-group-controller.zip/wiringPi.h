#ifndef WIRINGPI_H
#define WIRINGPI_H

#define	INPUT			 0
#define	OUTPUT			 1

extern int wiringPiSetup(void);
extern void pinMode(int pin, int mode) ;
extern int digitalRead (int pin);
extern void digitalWrite(int pin, int value) ;

#endif // WIRINGPI_H
