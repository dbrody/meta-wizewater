#ifndef STATIONGROUPIOTIVITYSERVER_H
#define STATIONGROUPIOTIVITYSERVER_H

#include <QObject>

#include <ocstack.h>
#include <OCPlatform.h>
#include <OCApi.h>

#include "defines.h"
#include "iotivitystationresource.h"

using namespace std;
using namespace OC;
namespace PH = std::placeholders;


class IoTivityStationGroupServer : public QObject
{
    Q_OBJECT
public:
    explicit IoTivityStationGroupServer(QObject *parent = nullptr);
    ~IoTivityStationGroupServer();

    void addStation(int n);
    void setStation(int n, bool on);

    std::string deviceUuid;

private:
    void initializePlatform();
    void registerPlatformInfo();
    OCStackResult SetDeviceInfo();
    void DeletePlatformInfo();

    void listenForDevices();
    void foundDevice(std::shared_ptr<OCResource> resource);

    std::vector<IoTivityStationResource *> stations;

signals:
    void stationUpdated(IoTivityStationResource* station);
};

#endif // STATIONGROUPIOTIVITYSERVER_H
