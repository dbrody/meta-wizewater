#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QKeyEvent>
#include <wiringPi.h>
#include <ocstack.h>
#include <OCPlatform.h>
#include <OCApi.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    wiringPiSetup();
    setUpPin(RELAY_1_PIN);
    setUpPin(RELAY_2_PIN);
    setUpPin(RELAY_3_PIN);
    setUpPin(RELAY_4_PIN);
    setUpPin(RELAY_5_PIN);
    setUpPin(RELAY_6_PIN);
    setUpPin(RELAY_7_PIN);
    setUpPin(RELAY_8_PIN);

    server = new IoTivityStationGroupServer();
    server->addStation(1);
    server->addStation(2);
    server->addStation(3);
    server->addStation(4);
    server->addStation(5);
    server->addStation(6);
    server->addStation(7);
    server->addStation(8);

    connect(server, SIGNAL(stationUpdated(IoTivityStationResource*)), this, SLOT(stationUpdated(IoTivityStationResource*)));
}

MainWindow::~MainWindow()
{
    closePin(RELAY_1_PIN);
    closePin(RELAY_2_PIN);
    closePin(RELAY_3_PIN);
    closePin(RELAY_4_PIN);
    closePin(RELAY_5_PIN);
    closePin(RELAY_6_PIN);
    closePin(RELAY_7_PIN);
    closePin(RELAY_8_PIN);
    delete ui;
}

void MainWindow::stationUpdated(IoTivityStationResource *station)
{
    std::cout << "Signal! Station Update: " << station->resourceURI << std::endl;
    QPushButton* btn;
    switch(station->m_n){
        case 1: btn = ui->pushButton_1; break;
        case 2: btn = ui->pushButton_2; break;
        case 3: btn = ui->pushButton_3; break;
        case 4: btn = ui->pushButton_4; break;
        case 5: btn = ui->pushButton_5; break;
        case 6: btn = ui->pushButton_6; break;
        case 7: btn = ui->pushButton_7; break;
        case 8: btn = ui->pushButton_8; break;
    }
    if(btn){
        std::cout << "  Setting to: " << station->m_isOn << std::endl;
        btn->setChecked(station->m_isOn);
    }
}

void MainWindow::on_pushButton_1_clicked(bool checked)
{
    togglePinValue(RELAY_1_PIN);
    server->setStation(1, checked);
}

void MainWindow::on_pushButton_2_clicked(bool checked)
{
    togglePinValue(RELAY_2_PIN);
    server->setStation(1, checked);
}

void MainWindow::on_pushButton_3_clicked(bool checked)
{
    togglePinValue(RELAY_3_PIN);
    server->setStation(1, checked);
}

void MainWindow::on_pushButton_4_clicked(bool checked)
{
    togglePinValue(RELAY_4_PIN);
    server->setStation(1, checked);
}

void MainWindow::on_pushButton_5_clicked(bool checked)
{
    togglePinValue(RELAY_5_PIN);
    server->setStation(1, checked);
}

void MainWindow::on_pushButton_6_clicked(bool checked)
{
    togglePinValue(RELAY_6_PIN);
    server->setStation(1, checked);
}

void MainWindow::on_pushButton_7_clicked(bool checked)
{
    togglePinValue(RELAY_7_PIN);
    server->setStation(1, checked);
}

void MainWindow::on_pushButton_8_clicked(bool checked)
{
    togglePinValue(RELAY_8_PIN);
    server->setStation(1, checked);
}

void MainWindow::setUpPin(int pin)
{
    pinMode(pin, OUTPUT);
    digitalWrite(pin, 1);
}

void MainWindow::togglePinValue(int pin)
{
    int value = digitalRead(pin);
    digitalWrite(pin, 1 - value);
}

void MainWindow::closePin(int pin)
{
    digitalWrite(pin, 1);
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch(event->key())
    {
        case Qt::Key_Escape:
            close();
            break;
        default:
            QMainWindow::keyPressEvent(event);
    }
}
