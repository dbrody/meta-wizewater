#include "mainwindow.h"

#include <QtWidgets/QApplication>
#include <QtQml/QQmlApplicationEngine>
#include <QtQml/QQmlContext>
#include <QtQuick/QQuickWindow>
#include <QtGui/QImageReader>
#include <QtCore/QCommandLineParser>
#include <QtCore/QCommandLineOption>
#include <QtCore/QDebug>
#include <QtCore/QDir>
#include <QtCore/QMimeDatabase>
#include <QtCore/QStandardPaths>
#include <QtCore/QUrl>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
//    MainWindow w;
//    w.setCursor(Qt::BlankCursor);
//    w.show();
//    // w.showFullScreen();
//    return a.exec();

    QQuickWindow::setDefaultAlphaBuffer(true);

    QCoreApplication::setApplicationName(QStringLiteral("Photosurface"));
    QCoreApplication::setOrganizationName(QStringLiteral("QtProject"));
    QCoreApplication::setApplicationVersion(QLatin1String(QT_VERSION_STR));
    QCommandLineParser parser;
    parser.setApplicationDescription(QStringLiteral("Qt Quick Demo - Photo Surface"));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument(QStringLiteral("directory"),
                                 QStringLiteral("The image directory or URL to show."));
    parser.process(app);

    QUrl initialUrl;
    if (!parser.positionalArguments().isEmpty()) {
        initialUrl = QUrl::fromUserInput(parser.positionalArguments().first(),
                                         QDir::currentPath(), QUrl::AssumeLocalFile);
        if (!initialUrl.isValid()) {
            qWarning().nospace() << "Invalid argument: \""
                << parser.positionalArguments().first() << "\": " << initialUrl.errorString();
            return 1;
        }
    }

    QQmlApplicationEngine engine;
    QQmlContext *context = engine.rootContext();


    QStringList dataList;
    dataList.append("Item 1");
    dataList.append("Item 2");
    dataList.append("Item 3");
    dataList.append("Item 4");
    dataList.append("Item 5");
    dataList.append("Item 6");
    dataList.append("Item 7");
    dataList.append("Item 8");
    context->setContextProperty(QStringLiteral("myModel"), dataList);

    engine.load(QUrl("qrc:///station-group-controller.qml"));
    if (engine.rootObjects().isEmpty())
        return -1;
    return app.exec();
}
