#include "iotivitystationgroupserver.h"
#include <QDebug>
#include <mutex>

#include <boost/uuid/uuid.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <boost/lexical_cast.hpp>

OCPlatformInfo platformInfo;
std::mutex curResourceLock;

IoTivityStationGroupServer::IoTivityStationGroupServer(QObject *parent) : QObject(parent)
{
    boost::uuids::random_generator gen;
    boost::uuids::uuid id = gen();
    deviceUuid = boost::lexical_cast<std::string>(id);

    initializePlatform();
    registerPlatformInfo();
    if(SetDeviceInfo() == OC_STACK_OK){
        cout << "SetDeviceInfo - yes" << endl;
    }
    listenForDevices();
    DeletePlatformInfo();
}

IoTivityStationGroupServer::~IoTivityStationGroupServer()
{
    cout << "Running IoTServer destructor" << endl;
    OC_VERIFY(OCPlatform::stop() == OC_STACK_OK);
}

void IoTivityStationGroupServer::addStation(int n)
{
    cout << "Adding Station: " << n << endl;
    IoTivityStationResource* resource = new IoTivityStationResource(deviceUuid, n);
    resource->create();
    stations.push_back(resource);
    connect(resource, SIGNAL(updated(IoTivityStationResource*)), this, SIGNAL(stationUpdated(IoTivityStationResource*)));
    cout << "Total Stations: " << stations.size() << endl;
}

void IoTivityStationGroupServer::setStation(int n, bool on)
{
    stations.at(n)->setIsOn(on);
}

void IoTivityStationGroupServer::initializePlatform()
{
    qDebug() << "Running IoTServer constructor";

    PlatformConfig cfg
    {
        ServiceType::InProc,
        ModeType::Both,
        "0.0.0.0",
        0,
        QualityOfService::HighQos
    };

    OCPlatform::Configure(cfg);
    OC_VERIFY(OCPlatform::start() == OC_STACK_OK);
}


void IoTivityStationGroupServer::listenForDevices()
{
    std::cout << "Listening for other devices..." << std::endl;
    FindCallback f (std::bind(&IoTivityStationGroupServer::foundDevice, this, PH::_1));
    OCStackResult result = OCPlatform::findResource("", OC_RSRVD_WELL_KNOWN_URI, CT_DEFAULT, f);
}

void DuplicateString(char ** targetString, std::string sourceString)
{
    *targetString = new char[sourceString.length() + 1];
    strncpy(*targetString, sourceString.c_str(), (sourceString.length() + 1));
}

void IoTivityStationGroupServer::registerPlatformInfo()
{
    DuplicateString(&platformInfo.platformID, platformId);
    DuplicateString(&platformInfo.manufacturerName, manufacturerName);
    DuplicateString(&platformInfo.manufacturerUrl, manufacturerLink);
    DuplicateString(&platformInfo.modelNumber, modelNumber);
    DuplicateString(&platformInfo.dateOfManufacture, dateOfManufacture);
    DuplicateString(&platformInfo.platformVersion, platformVersion);
    DuplicateString(&platformInfo.operatingSystemVersion, operatingSystemVersion);
    DuplicateString(&platformInfo.hardwareVersion, hardwareVersion);
    DuplicateString(&platformInfo.firmwareVersion, firmwareVersion);
    DuplicateString(&platformInfo.supportUrl, supportLink);
    DuplicateString(&platformInfo.systemTime, systemTime);

    // Register elevator's platformInfo, deviceInfo, and resource.
    if (OC_STACK_OK == OCPlatform::registerPlatformInfo(platformInfo))
    {
        std::cout << "--------" << std::endl;
        std::cout << "Platform Registered:" << std::endl;
        std::cout << "  " << manufacturerName << "(" << modelNumber << ")" << std::endl;
    }
}

void IoTivityStationGroupServer::DeletePlatformInfo()
{
    delete[] platformInfo.platformID;
    delete[] platformInfo.manufacturerName;
    delete[] platformInfo.manufacturerUrl;
    delete[] platformInfo.modelNumber;
    delete[] platformInfo.dateOfManufacture;
    delete[] platformInfo.platformVersion;
    delete[] platformInfo.operatingSystemVersion;
    delete[] platformInfo.hardwareVersion;
    delete[] platformInfo.firmwareVersion;
    delete[] platformInfo.supportUrl;
    delete[] platformInfo.systemTime;
}

OCStackResult IoTivityStationGroupServer::SetDeviceInfo()
{
    OCStackResult result = OCPlatform::setPropertyValue(PAYLOAD_TYPE_DEVICE, OC_RSRVD_DEVICE_NAME,
                                                        deviceName);
    if (result != OC_STACK_OK)
        std::cout << "Error - Set device name" << std::endl;

    result = OCPlatform::setPropertyValue(PAYLOAD_TYPE_DEVICE, OC_RSRVD_DATA_MODEL_VERSION,
                                          dataModelVersions);
    if (result != OC_STACK_OK)
        std::cout << "Error - Set data model versions" << std::endl;

    result = OCPlatform::setPropertyValue(PAYLOAD_TYPE_DEVICE, OC_RSRVD_SPEC_VERSION, specVersion);
    if (result != OC_STACK_OK)
        std::cout << "Error - Set spec version" << std::endl;

    result = OCPlatform::setPropertyValue(PAYLOAD_TYPE_DEVICE, OC_RSRVD_PROTOCOL_INDEPENDENT_ID,
                                          protocolIndependentID);
    if (result != OC_STACK_OK)
        std::cout << "Error - Set piid" << std::endl;

    std::cout << "--------" << std::endl;
    std::cout << "Device Registered: " << std::endl;
    std::cout << "  Device: " << deviceName << std::endl;
    std::cout << "      ID: " << protocolIndependentID << std::endl;

    return OC_STACK_OK;
}

void IoTivityStationGroupServer::foundDevice(std::shared_ptr<OCResource> resource)
{
    std::lock_guard<std::mutex> lock(curResourceLock);
    std::cout << "Found Device: " << std::endl;
    std::cout << "  Device: " << resource->host() << ":" << resource->uri() << std::endl;
}
