#include "iotivitystationresource.h"

IoTivityStationResource::IoTivityStationResource(QObject *parent)
{
    IoTivityStationResource("wizewater", 1, parent);
}

IoTivityStationResource::IoTivityStationResource(std::string deviceUuid, int n, QObject *parent) :
    QObject(parent), m_n(n), m_isOn(false)
{
    resourceURI = "/" + deviceUuid + "/station/" + std::to_string(m_n);
    resourceTypeName = "wizewater.station";
}

void IoTivityStationResource::create()
{
    std::cout << "Creating IoTivityStationResource: " << resourceURI << std::endl;
    std::string resourceInterface = OC_RSRVD_INTERFACE_ACTUATOR;

    uint8_t resourceProperty = OC_DISCOVERABLE | OC_OBSERVABLE;
    OCStackResult result = OCPlatform::registerResource(m_resourceHandle,
        resourceURI,
        resourceTypeName,
        resourceInterface,
        EntityHandler(std::bind(&IoTivityStationResource::entityHandler, this, PH::_1)),
        resourceProperty);
    OCPlatform::bindInterfaceToResource(m_resourceHandle, DEFAULT_INTERFACE);

    if(OC_STACK_OK != result)
    {
        throw std::runtime_error(
            std::string("Switch Resource failed to start")+std::to_string(result));
    } else {
        std::cout << "IoTSwitchResource start" << std::endl;
    }
}

OCEntityHandlerResult IoTivityStationResource::entityHandler(std::shared_ptr<OCResourceRequest> request)
{
    std::cout << "entityHandler: " << std::endl;
    OCEntityHandlerResult ehResult = OC_EH_ERROR;
    if(request->getRequestHandlerFlag() == RequestHandlerFlag::RequestFlag)
    {
        auto pResponse = std::make_shared<OC::OCResourceResponse>();
        pResponse->setRequestHandle(request->getRequestHandle());
        pResponse->setResourceHandle(request->getResourceHandle());

        if(request->getRequestType() == "GET")
        {
            std::cout<<"Station Get Request"<<std::endl;
            pResponse->setResponseResult(OC_EH_OK);
            pResponse->setResourceRepresentation(get(), "");
            if(OC_STACK_OK == OCPlatform::sendResponse(pResponse))
            {
                ehResult = OC_EH_OK;
            }
        }
        else if(request->getRequestType() == "PUT")
        {
            std::cout <<"Station Put Request"<<std::endl;
            put(request->getResourceRepresentation());
            pResponse->setResourceRepresentation(get(), "");
            if(OC_STACK_OK == OCPlatform::sendResponse(pResponse))
            {
                ehResult = OC_EH_OK;
            }
        }
        else
        {
            std::cout <<"Station unsupported request type "
            << request->getRequestType() << std::endl;
            pResponse->setResponseResult(OC_EH_ERROR);
            OCPlatform::sendResponse(pResponse);
            ehResult = OC_EH_ERROR;
        }
    }
    else
    {
        std::cout << "DeviceResource unsupported request flag" <<std::endl;
    }
    return ehResult;
}

void IoTivityStationResource::setIsOn(bool on)
{
    std::cout << "Station " << resourceURI << " is on = " << on << std::endl;
    m_isOn = on;
    OCPlatform::notifyAllObservers(m_resourceHandle);
}

OCRepresentation IoTivityStationResource::get()
{
    m_rep.setValue("on", m_isOn);
    return m_rep;
}

void IoTivityStationResource::put(const OCRepresentation& rep)
{
    rep.getValue("on", m_isOn);
    emit updated(this);
}
