#ifndef DEFINES_H
#define DEFINES_H

// Set of strings for each of platform Info fields
const std::string  platformId = "1A3E0D6F-DBF5-404E-8719-D6880042463A";
const std::string  manufacturerName = "WizeWater";
const std::string  manufacturerLink = "https://www.wizewater.us";
const std::string  modelNumber = "ww-ss-0.0.1";
const std::string  dateOfManufacture = "2017-12-01";
const std::string  platformVersion = "0.0.1";
const std::string  operatingSystemVersion = "ww-0.0.1";
const std::string  hardwareVersion = "ss-0.0.1";
const std::string  firmwareVersion = "1.0";
const std::string  supportLink = "https://www.wizewater.us";
const std::string  systemTime = "2016-01-15T11.01";

// Set of strings for each of device info fields
const std::string  deviceName = "Waterwize Station Controller";
const std::string  specVersion = "0.0.1";
const std::vector<std::string> dataModelVersions = {"ocf.res.1.1.0"};
const std::string  protocolIndependentID = "154718eb-b1e7-4e9e-9892-30e718a6a8f3";

#endif // DEFINES_H
