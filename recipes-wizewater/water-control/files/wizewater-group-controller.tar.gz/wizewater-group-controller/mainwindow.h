#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "iotivitystationgroupserver.h"

#define RELAY_1_PIN 21 // Pin 29
#define RELAY_2_PIN 22 // Pin 31
#define RELAY_3_PIN 23 // Pin 33
#define RELAY_4_PIN 24 // Pin 35
#define RELAY_5_PIN 25 // Pin 37
#define RELAY_6_PIN 26 // Pin 32
#define RELAY_7_PIN 27 // Pin 36
#define RELAY_8_PIN 28 // Pin 38

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    IoTivityStationGroupServer* server;

protected:
    void keyPressEvent(QKeyEvent *event);

private slots:
    void stationUpdated(IoTivityStationResource* station);
    void on_pushButton_1_clicked(bool checked);
    void on_pushButton_2_clicked(bool checked);
    void on_pushButton_3_clicked(bool checked);
    void on_pushButton_4_clicked(bool checked);
    void on_pushButton_5_clicked(bool checked);
    void on_pushButton_6_clicked(bool checked);
    void on_pushButton_7_clicked(bool checked);
    void on_pushButton_8_clicked(bool checked);

private:
    Ui::MainWindow *ui;

    void setUpPin(int pin);
    void closePin(int pin);
    void togglePinValue(int pin);
};

#endif // MAINWINDOW_H
